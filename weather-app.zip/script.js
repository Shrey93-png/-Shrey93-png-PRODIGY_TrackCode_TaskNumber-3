const apiKey = "YOUR_API_KEY"; // <-- Replace this with your OpenWeatherMap API key

function getWeather() {
  const city = document.getElementById("cityInput").value.trim();
  const display = document.getElementById("weatherDisplay");

  if (!city) {
    display.innerHTML = "<p style='color: red;'>Please enter a city name.</p>";
    return;
  }

  const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

  fetch(url)
    .then((response) => response.json())
    .then((data) => {
      if (data.cod !== 200) {
        display.innerHTML = `<p style='color: red;'>${data.message}</p>`;
        return;
      }

      const icon = data.weather[0].icon;
      const html = `
        <h2>${data.name}, ${data.sys.country}</h2>
        <img src="https://openweathermap.org/img/wn/${icon}@2x.png" alt="Weather icon" />
        <p>Temperature: ${data.main.temp}°C</p>
        <p>Condition: ${data.weather[0].description}</p>
      `;
      display.innerHTML = html;
    })
    .catch((error) => {
      display.innerHTML = `<p style='color: red;'>Unable to fetch weather data.</p>`;
      console.error(error);
    });
}
